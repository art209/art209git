<?php
/**
 * The template used for displaying secondary page header
 * Description: New header stuff
 *
 * @package Toolbox
 * @since Toolbox 0.1
 */
?>
<div id="secondarypage-header">
</div>
	